package gg.cncmc.battleteams.commands;

import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import gg.cncmc.battleteams.utility.LuckPermsHook;
import gg.cncmc.battleteams.utility.teamStorage;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.class_124;
import net.minecraft.class_1657;
import net.minecraft.class_2168;
import net.minecraft.class_2186;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;

import static net.minecraft.class_2170.method_9244;
import static net.minecraft.class_2170.method_9247;

public class battleTeamsCommand {
    public static void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            dispatcher.register(method_9247("battleteams")
                    .then(method_9247("attacker")
                            .executes(battleTeamsCommand::attacker)
                    )
                    .then(method_9247("defender")
                            .executes(battleTeamsCommand::defender)
                    )
                    .then(method_9247("press")
                            .executes(battleTeamsCommand::press)
                            .then(method_9247("accept")
                                    .requires(source -> hasPermission(source, "battleteams.manage"))
                                    .then(method_9244("target", class_2186.method_9305())
                                            .executes(battleTeamsCommand::pressAccept)
                                    )
                            )
                    )
                    .then(method_9247("clear")
                            .requires(source -> hasPermission(source, "battleteams.manage"))
                            .executes(battleTeamsCommand::clear)
                    )
            );
        });
    }

    private static boolean hasPermission(class_2168 source, String permission) {
        if (!source.method_43737()) return true;

        try {
            Class.forName("net.luckperms.api.LuckPermsProvider");
        } catch (ClassNotFoundException e) {
            return source.method_9259(2);
        }

        return LuckPermsHook.hasPermission(source, permission);
    }

    private static int attacker(CommandContext<class_2168> ctx) {
        class_2168 source = ctx.getSource();

        if (!(source.method_9228() instanceof class_1657 player)) {
            source.method_9226(() -> class_2561.method_43470("Only players can use this!"), false);
            return 0;
        }

        String playerName = player.method_5477().getString();
        teamStorage storage = teamStorage.getInstance(source.method_9211());

        storage.addAttacker(playerName);

        source.method_9211().method_3734().method_44252(
                source.method_9211().method_3739(),
                "lp user " + playerName + " parent add attacker"
        );

        source.method_9226(() ->
                class_2561.method_43470("[BattleTeams] You are now an Attacker").method_27692(class_124.field_1061), false);

        return 1;
    }

    private static int defender(CommandContext<class_2168> ctx) {
        class_2168 source = ctx.getSource();

        if (!(source.method_9228() instanceof class_1657 player)) {
            source.method_9226(() -> class_2561.method_43470("Only players can use this!"), false);
            return 0;
        }

        String playerName = player.method_5477().getString();
        teamStorage storage = teamStorage.getInstance(source.method_9211());

        storage.addDefender(playerName);

        source.method_9211().method_3734().method_44252(
                source.method_9211().method_3739(),
                "lp user " + playerName + " parent add defender"
        );

        source.method_9226(() ->
                class_2561.method_43470("[BattleTeams] You are now a Defender").method_27692(class_124.field_1078), false);

        return 1;
    }

    private static int press(CommandContext<class_2168> ctx) {
        class_2168 source = ctx.getSource();

        if (!(source.method_9228() instanceof class_1657 player)) {
            source.method_9226(() -> class_2561.method_43470("Only players can use this!"), false);
            return 0;
        }

        String playerName = player.method_5477().getString();

        source.method_9226(() ->
                class_2561.method_43470("[BattleTeams] You must be accepted by staff!").method_27692(class_124.field_1054), false);

        broadcastToPermission(
                source.method_9211(),
                "battleteams.manage",
                class_2561.method_43470("[BattleTeams] " + playerName + " is requesting to become press! /battleteams press accept " + playerName).method_27692(class_124.field_1054)
        );

        return 1;
    }

    private static int pressAccept(CommandContext<class_2168> ctx) throws CommandSyntaxException {
        class_2168 source = ctx.getSource();
        class_3222 target = class_2186.method_9315(ctx, "target");
        String playerName = target.method_5477().getString();
        teamStorage storage = teamStorage.getInstance(source.method_9211());

        storage.addPress(playerName);

        source.method_9211().method_3734().method_44252(
                source.method_9211().method_3739(),
                "lp user " + playerName + " parent add press"
        );

        source.method_9211().method_3734().method_44252(
                source.method_9211().method_3739(),
                "gamemode spectator " + playerName
        );

        target.method_43496(class_2561.method_43470("[BattleTeams] You have been accepted as press!").method_27692(class_124.field_1060));

        source.method_9226(() ->
                class_2561.method_43470("[BattleTeams] Accepted " + playerName + " as press!").method_27692(class_124.field_1060), false);

        return 1;
    }

    private static int clear(CommandContext<class_2168> ctx) {
        class_2168 source = ctx.getSource();
        MinecraftServer server = source.method_9211();
        teamStorage storage = teamStorage.getInstance(server);

        // Remove attacker roles
        for (String playerName : storage.getAttackers()) {
            server.method_3734().method_44252(
                    server.method_3739(),
                    "lp user " + playerName + " parent remove attacker"
            );
        }

        // Remove defender roles
        for (String playerName : storage.getDefenders()) {
            server.method_3734().method_44252(
                    server.method_3739(),
                    "lp user " + playerName + " parent remove defender"
            );
        }

        // Set press back to survival
        for (String playerName : storage.getPress()) {
            server.method_3734().method_44252(
                    server.method_3739(),
                    "gamemode survival " + playerName
            );

            server.method_3734().method_44252(
                    server.method_3739(),
                    "lp user " + playerName + " parent remove press"
            );
        }

        storage.clearAll();

        source.method_9226(() ->
                class_2561.method_43470("[BattleTeams] All teams cleared!").method_27692(class_124.field_1060), false);

        return 1;
    }

    private static void broadcastToPermission(MinecraftServer server, String permission, class_2561 message) {
        for (class_3222 player : server.method_3760().method_14571()) {
            if (hasPermission(player.method_5671(), permission)) {
                player.method_43496(message);
            }
        }
    }
}